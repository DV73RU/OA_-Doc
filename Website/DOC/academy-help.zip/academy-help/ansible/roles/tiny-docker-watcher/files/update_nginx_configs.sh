#!/usr/bin/env bash

while IFS=, read docker_image_name branch url nginx_config leurl; do
    export CONTAINER_PORT=$(docker inspect --format='{{(index (index .NetworkSettings.Ports "80/tcp") 0).HostPort}}' $docker_image_name-$branch)
    if [ ! -z $CONTAINER_PORT ] ; then
        export DOCKER_IMAGE_NAME=$docker_image_name;
        export BRANCH=$branch;
        export URL=$url;
        export LEURL=$leurl

        envsubst '$BRANCH $CONTAINER_PORT $DOCKER_IMAGE_NAME $URL $LEURL' < /opt/tiny-docker-watcher/$nginx_config > /etc/nginx/sites-enabled/tdw-$docker_image_name-$branch
    fi
done < /opt/tiny-docker-watcher/production-servers-db.txt

for i in `seq 1 10`; do
    if curl --connect-timeout 10 --max-time 30 -L -s -I http://127.0.0.1:{$CONTAINER_PORT} | grep -q 'HTTP'; then
	echo App started - relading nginx && break
    else
     echo "Waiting for app start - ${i}" && sleep 5
    fi
done


sudo nginx -s reload;