#!/usr/bin/env bash

echo "#################";
echo "Запускаем новую копию приложения"
echo "#################";

docker rm -f $DOCKER_IMAGE_NAME-$BRANCH-old || true;
docker rename $DOCKER_IMAGE_NAME-$BRANCH $DOCKER_IMAGE_NAME-$BRANCH-old || true;

if [ -z $RUN_METHOD ] ; then
    export RUN_METHOD=django-ordinary;
fi

if [ -z $STAGING_STRATEGY ] ; then
    export STAGING_STRATEGY=master-production-divided;
fi

case "$RUN_METHOD" in
    django-ordinary )
        MYSQL_DATABASE_NAME=$MYSQL_DB_PREFIX$BRANCH;

        echo "-> Сохраняем резервную копию master и production баз данных. Для master храним только последнюю версию, для production все";

        mkdir -p /backup/$PROJECT_NAME/production-versioned;
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-versioned/$CI_BUILD_ID.sql;";

        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-versioned/production-$CI_BUILD_ID.sql;";

        if [ $BRANCH = "master" ] && [ $STAGING_STRATEGY = "master-production-linked" ] ; then
            echo "#################";
            echo "Собираем базу данных master как копию production"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/production-media/* /docker_volumes/$DOCKER_IMAGE_NAME/master-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/production-latest.sql;"
        fi

        if [ $BRANCH != "master" ] && [ $BRANCH != "production" ] ; then
            echo "#################";
            echo "Собираем тестовую базу данных как копию master и копируем медиафайлы"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/master-media/* /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/master-latest.sql;"
        fi

        if [ -z $DJANGO_DEFAULT_PROJECT ] ; then
            export DJANGO_DEFAULT_PROJECT=Project
        fi

        docker run --rm --link super5-db:mysql-charset -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME $DOCKER_IMAGE_NAME-$BRANCH /bin/sh -c 'cd /opt/app && python3 manage.py migrate --noinput --settings='$DJANGO_DEFAULT_PROJECT'.production_settings'

        if [ $BRANCH = "production" ] || [ $BRANCH = "master" ] ; then
            docker run --restart=always --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset -e BRANCH=$BRANCH -e CI_BUILD_REF=$CI_BUILD_REF -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        else
            docker run --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset -e BRANCH=$BRANCH -e CI_BUILD_REF=$CI_BUILD_REF -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        fi
    ;;
    django-ordinary-redis )
        MYSQL_DATABASE_NAME=$MYSQL_DB_PREFIX$BRANCH;

        echo "-> Сохраняем резервную копию master и production баз данных. Для master храним только последнюю версию, для production все";

        mkdir -p /backup/$PROJECT_NAME/production-versioned;
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-versioned/$CI_BUILD_ID.sql;";

        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-versioned/production-$CI_BUILD_ID.sql;";

        if [ $BRANCH = "master" ] && [ $STAGING_STRATEGY = "master-production-linked" ] ; then
            echo "#################";
            echo "Собираем базу данных master как копию production"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/production-media/* /docker_volumes/$DOCKER_IMAGE_NAME/master-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/production-latest.sql;"
        fi

        if [ $BRANCH != "master" ] && [ $BRANCH != "production" ] ; then
            echo "#################";
            echo "Собираем тестовую базу данных как копию master и копируем медиафайлы"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/master-media/* /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/master-latest.sql;"
        fi

        if [ -z $DJANGO_DEFAULT_PROJECT ] ; then
            export DJANGO_DEFAULT_PROJECT=Project
        fi

        docker run --rm --link super5-db:mysql-charset -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME $DOCKER_IMAGE_NAME-$BRANCH /bin/sh -c 'cd /opt/app && python3 manage.py migrate --noinput --settings='$DJANGO_DEFAULT_PROJECT'.production_settings'

        if [ $BRANCH = "production" ] || [ $BRANCH = "master" ] ; then
            docker run --restart=always --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset --link redis-db:redis-db -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        else
            docker run --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset --link redis-db:redis-db -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        fi
    ;;
    django-memcached-rabbit )
        MYSQL_DATABASE_NAME=$MYSQL_DB_PREFIX$BRANCH;

        echo "-> Сохраняем резервную копию master и production баз данных. Для master храним только последнюю версию, для production все";

        mkdir -p /backup/$PROJECT_NAME/production-versioned;
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-versioned/$CI_BUILD_ID.sql;";

        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-versioned/production-$CI_BUILD_ID.sql;";
        echo "#################";
        echo "Создаем vhost в rabbitmq"
        echo "#################";

    docker exec -e BRANCH=$BRANCH rabbitmq bash -c '$(rabbitmqctl list_vhosts | grep -q "${BRANCH}") || rabbitmqctl add_vhost ${BRANCH} && rabbitmqctl set_permissions -p ${BRANCH} guest ".*" ".*" ".*"'

        if [ $BRANCH = "master" ] && [ $STAGING_STRATEGY = "master-production-linked" ] ; then
            echo "#################";
            echo "Собираем базу данных master как копию production"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/production-media/* /docker_volumes/$DOCKER_IMAGE_NAME/master-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/production-latest.sql;"
        fi

        if [ $BRANCH != "master" ] && [ $BRANCH != "production" ] ; then
            echo "#################";
            echo "Собираем тестовую базу данных как копию master и копируем медиафайлы"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/master-media/* /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/master-latest.sql;"
        fi

        if [ -z $DJANGO_DEFAULT_PROJECT ] ; then
            export DJANGO_DEFAULT_PROJECT=Project
        fi

        docker run --rm --link super5-db:mysql-charset -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME $DOCKER_IMAGE_NAME-$BRANCH /bin/sh -c 'cd /opt/app && python3 manage.py migrate --noinput --settings='$DJANGO_DEFAULT_PROJECT'.production_settings'

        if [ $BRANCH = "production" ] || [ $BRANCH = "master" ] ; then
            docker run --restart=always --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset --link memcached:memcached --link rabbitmq:rabbitmq -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        else
            docker run --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset --link memcached:memcached --link rabbitmq:rabbitmq -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        fi
    ;;
    django-redis-rabbitmq )
        MYSQL_DATABASE_NAME=$MYSQL_DB_PREFIX$BRANCH;

        echo "-> Сохраняем резервную копию master и production баз данных. Для master храним только последнюю версию, для production все";

        mkdir -p /backup/$PROJECT_NAME/production-versioned;
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-versioned/$CI_BUILD_ID.sql;";

        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-versioned/production-$CI_BUILD_ID.sql;";

        if [ $BRANCH = "master" ] && [ $STAGING_STRATEGY = "master-production-linked" ] ; then
            echo "#################";
            echo "Собираем базу данных master как копию production"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/production-media/* /docker_volumes/$DOCKER_IMAGE_NAME/master-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/production-latest.sql;"
        fi

        if [ $BRANCH != "master" ] && [ $BRANCH != "production" ] ; then
            echo "#################";
            echo "Собираем тестовую базу данных как копию master и копируем медиафайлы"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/master-media/* /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/master-latest.sql;"
        fi

    echo "#################";
        echo "Создаем vhost в rabbitmq"
        echo "#################";

    docker exec -e BRANCH=$BRANCH rabbitmq bash -c '$(rabbitmqctl list_vhosts | grep -q "${BRANCH}") || rabbitmqctl add_vhost ${BRANCH} && rabbitmqctl set_permissions -p ${BRANCH} guest ".*" ".*" ".*"'


        if [ -z $DJANGO_DEFAULT_PROJECT ] ; then
            export DJANGO_DEFAULT_PROJECT=Project
        fi

        docker run --rm --link super5-db:mysql-charset -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME $DOCKER_IMAGE_NAME-$BRANCH /bin/sh -c 'cd /opt/app && python3 manage.py migrate --noinput --settings='$DJANGO_DEFAULT_PROJECT'.production_settings'

        if [ $BRANCH = "production" ] || [ $BRANCH = "master" ] ; then
            docker run --restart=always --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link redis-db:redis-db --link super5-db:mysql-charset --link rabbitmq:rabbitmq -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        else
            docker run --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link redis-db:redis-db --link super5-db:mysql-charset --link rabbitmq:rabbitmq -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        fi
    ;;
    django-ordinary-rabbitmq )
        MYSQL_DATABASE_NAME=$MYSQL_DB_PREFIX$BRANCH;

        echo "-> Сохраняем резервную копию master и production баз данных. Для master храним только последнюю версию, для production все";

        mkdir -p /backup/$PROJECT_NAME/production-versioned;
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-versioned/$CI_BUILD_ID.sql;";

        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-versioned/production-$CI_BUILD_ID.sql;";

        if [ $BRANCH = "master" ] && [ $STAGING_STRATEGY = "master-production-linked" ] ; then
            echo "#################";
            echo "Собираем базу данных master как копию production"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/production-media/* /docker_volumes/$DOCKER_IMAGE_NAME/master-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/production-latest.sql;"
        fi

        if [ $BRANCH != "master" ] && [ $BRANCH != "production" ] ; then
            echo "#################";
            echo "Собираем тестовую базу данных как копию master и копируем медиафайлы"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/master-media/* /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/master-latest.sql;"
        fi

    echo "#################";
        echo "Создаем vhost в rabbitmq"
        echo "#################";

    docker exec -e BRANCH=$BRANCH rabbitmq bash -c '$(rabbitmqctl list_vhosts | grep -q "${BRANCH}") || rabbitmqctl add_vhost ${BRANCH} && rabbitmqctl set_permissions -p ${BRANCH} guest ".*" ".*" ".*"'


        if [ -z $DJANGO_DEFAULT_PROJECT ] ; then
            export DJANGO_DEFAULT_PROJECT=Project
        fi

        docker run --rm --link super5-db:mysql-charset -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME $DOCKER_IMAGE_NAME-$BRANCH /bin/sh -c 'cd /opt/app && python3 manage.py migrate --noinput --settings='$DJANGO_DEFAULT_PROJECT'.production_settings'

        if [ $BRANCH = "production" ] || [ $BRANCH = "master" ] ; then
            docker run --restart=always --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset --link rabbitmq:rabbitmq -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        else
            docker run --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link super5-db:mysql-charset --link rabbitmq:rabbitmq -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e BRANCH=$BRANCH -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        fi
    ;;
    django-mysql-mq-mc )
        MYSQL_DATABASE_NAME=$MYSQL_DB_PREFIX$BRANCH;

        echo "-> Сохраняем резервную копию master и production баз данных. Для master храним только последнюю версию, для production все";

        mkdir -p /backup/$PROJECT_NAME/production-versioned;
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'master > /backup/master-versioned/$CI_BUILD_ID.sql;";

        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c 'mysqldump -u root -p$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-latest.sql;';
        docker run --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysqldump -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR '$MYSQL_DB_PREFIX'production > /backup/production-versioned/production-$CI_BUILD_ID.sql;";

	echo "#################";
        echo "Создаем vhost в rabbitmq"
        echo "#################";

        docker exec -e BRANCH=$BRANCH rabbitmq bash -c '$(rabbitmqctl list_vhosts | grep -q "${BRANCH}") || rabbitmqctl add_vhost ${BRANCH} && rabbitmqctl set_permissions -p ${BRANCH} guest ".*" ".*" ".*"'

        if [ $BRANCH = "master" ] && [ $STAGING_STRATEGY = "master-production-linked" ] ; then
            echo "#################";
            echo "Собираем базу данных master как копию production"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/production-media/* /docker_volumes/$DOCKER_IMAGE_NAME/master-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/production-latest.sql;"
        fi

        if [ $BRANCH != "master" ] && [ $BRANCH != "production" ] ; then
            echo "#################";
            echo "Собираем тестовую базу данных как копию master и копируем медиафайлы"
            echo "#################";
            cp -rf /docker_volumes/$DOCKER_IMAGE_NAME/master-media/* /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media;
            docker run --rm --link super5-db:mysql-charset -v /backup/$PROJECT_NAME:/backup $DOCKER_IMAGE_NAME-$BRANCH /bin/bash -c "mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"DROP DATABASE IF EXISTS $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR -e \"CREATE DATABASE $MYSQL_DB_PREFIX$BRANCH\"; mysql -u root -p\$MYSQL_CHARSET_ENV_MYSQL_ROOT_PASSWORD -h\$MYSQL_CHARSET_PORT_3306_TCP_ADDR $MYSQL_DB_PREFIX$BRANCH < /backup/master-latest.sql;"
        fi

        if [ $BRANCH = "production" ] || [ $BRANCH = "master" ] ; then
            docker run --restart=always --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS --link rabbitmq:rabbitmq --link memcached:memcached --link super5-db:mysql-charset -e BRANCH=$BRANCH -e CI_BUILD_REF=$CI_BUILD_REF -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e ENV=production -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/entrypoint.sh;
        else
            docker run --name $DOCKER_IMAGE_NAME-$BRANCH -v /docker_volumes/$DOCKER_IMAGE_NAME/$BRANCH-media:/opt/app/media $ADDITIONAL_DOCKER_PARAMETERS  --link rabbitmq:rabbitmq --link memcached:memcached --link super5-db:mysql-charset -e BRANCH=$BRANCH -e CI_BUILD_REF=$CI_BUILD_REF -e MYSQL_DATABASE_NAME=$MYSQL_DATABASE_NAME -e ENV=production -p 127.0.0.1::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/entrypoint.sh;
        fi
    ;;
    no-database-daemon )
        if [ $BRANCH = "production" ] || [ $BRANCH = "master" ] ; then
            docker run --restart=always --name $DOCKER_IMAGE_NAME-$BRANCH -p 0.0.0.0::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        else
            docker run --name $DOCKER_IMAGE_NAME-$BRANCH -p 0.0.0.0::80 -d $DOCKER_IMAGE_NAME-$BRANCH sh /opt/app/Deploy/start_in_docker.sh;
        fi
    ;;
    *)
        echo "Undefined RUN_METHOD";
        exit 1;
esac

echo "#################";
echo "Настраиваем маршрутизацию на nginx"
echo "#################";

cp ./Deploy/ssl.crt /opt/tiny-docker-watcher/ssl-keys/$DOCKER_IMAGE_NAME.crt;
cp ./Deploy/ssl.key /opt/tiny-docker-watcher/ssl-keys/$DOCKER_IMAGE_NAME.key;

if [ $BRANCH = "production" ] ; then
    export URL="$PRODUCTION_URL"
else
    export URL=$BRANCH.$PROJECT_NAME.huskyjam.com
fi

if [ -z $NGINX_CONFIG ] || [ $BRANCH != "production" ] ; then
    echo "Применяем стандарнтый конфиг"
    export NGINX_CONFIG=nginx-config;
fi

export DB_STRING="$DOCKER_IMAGE_NAME,$BRANCH,$URL,$NGINX_CONFIG,$LEURL"

if [ ! -z $(grep "$DB_STRING" /opt/tiny-docker-watcher/production-servers-db.txt) ]; then
    echo "Record in production-servers-db.txt exists.\n";
else
    echo $DB_STRING >> /opt/tiny-docker-watcher/production-servers-db.txt
fi

bash -c "/opt/tiny-docker-watcher/update_nginx_configs.sh";

echo "-> Останавливаем старую копию приложения."

docker rm -f $DOCKER_IMAGE_NAME-$BRANCH-old || true;

echo "-> Application url: $URL"

echo "-> Logs from container:"

docker logs $DOCKER_IMAGE_NAME-$BRANCH;

#echo "-> Clean up docker's garbage."
#
#docker rm $(docker ps -a -q) || true;
#
#docker images --quiet | xargs --no-run-if-empty docker rmi >/dev/null || true;